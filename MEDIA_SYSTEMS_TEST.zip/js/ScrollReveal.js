    window.ScrollReveal().reveal = ScrollReveal({
        reset: true,
    distance: "60px",
});

ScrollReveal().reveal('.left_picture', {
    delay: 200, origin: 'left', duration: 2000,
});

ScrollReveal().reveal('.tiles_images', {
    delay: 200, origin: 'left', duration: 3500,
});


ScrollReveal().reveal('.get_it_images', {
    delay: 200, origin: 'bottom', duration: 4500,
});


ScrollReveal().reveal('.save_images', {
    delay: 700, origin: 'top', duration: 6000,  distance: "0px"
});


ScrollReveal().reveal('.sankeramika_images', {
    delay: 200, origin: 'top', duration: 4500,
});


ScrollReveal().reveal('.right_side_picture', {
    delay: 200, origin: 'top', duration: 2500,
});

